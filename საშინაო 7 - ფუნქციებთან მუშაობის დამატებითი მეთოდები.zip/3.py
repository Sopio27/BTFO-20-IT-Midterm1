def rev(x):
    y=''
    # print(type(y))
    if(len(x)==0):
        return ''
    else:
        y+= x[len(x)-1] + rev(x[:len(x)-1])
        # print(type(y))
    return y

a = input("Sentence:")

print(rev(a))