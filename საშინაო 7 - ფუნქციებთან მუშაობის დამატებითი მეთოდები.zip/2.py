def calc(x):
    y=0
    if (x == 0):
        return 0
    else:
        y+=x%10 + calc((x - x%10)/10)

    return y

a = int(input("Enter a num:"))

print(calc(a))