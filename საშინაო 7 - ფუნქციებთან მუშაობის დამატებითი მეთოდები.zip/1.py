def calc(arg):
    x = 0
    for i in range(len(arg)):
       x+=arg[i]

    return x

lst = [100,20,30,50,5323,3321,22,56,700,90,10]

print(calc(lst))