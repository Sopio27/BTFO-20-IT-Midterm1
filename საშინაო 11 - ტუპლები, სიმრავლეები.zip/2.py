# დაწერეთ ფუნქცია რომელიც ატრიბუტად მიიღებს ორ tuple ტიპის მონაცემს, ფუნქციამ უნდა გააერთიანოს ეს ორი tuple და დააბრუნოს ერთი მთლიანი დუბლიკატების გარეშე, შექმენით სია duplicated_values და მასში დაამატეთ ის ინფორმაცია მხოლოდ ერთხელ, რომელიც დუბლირებული სახით გვხვდება tuple-ში, 
# დაბეჭდეთ მოცემული სია

# example:

# tuple1 = (1,2,3,4,5,6)

# tuple2 = (4,5,5,6,6,7)

# output:

# combined_tuple: (1,2,3,4,5,6,7)

# duplicated_values: [4,5,6]


tuple1 = (1,2,3,4,5,6)

tuple2 = (4,5,5,6,6,7)

def duplicated_values(a,b):
    set1 = set(tuple1)
    set2 = set(tuple2)

    duplicated_values=set1.intersection(set2)

    return duplicated_values

def combined_tuple(a,b):
    set1 = set(tuple1)
    set2 = set(tuple2)

    combined_tuple = set1.union(set2)

    return combined_tuple

print(combined_tuple(tuple1,tuple2))
print(duplicated_values(tuple1,tuple2))
