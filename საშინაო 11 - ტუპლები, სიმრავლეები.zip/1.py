# შექმენით ცვლადი squared_numbers რომელიც შეიცავს 1-დან 10-ის ჩათვლით კვადრატში აყვანილ რიცხვებს(არ შეავსოთ ხელით)

# მგონი პირობა ოდნავ ვერ გავიაზრე, სხვა მოთხოვნა ხომ არ იყო?

min = 1
max = 10
squared_numbers = set()
for i in (range(min,max+1)):
    squared_numbers.add(i**2)

print(squared_numbers)