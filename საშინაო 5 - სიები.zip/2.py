# შექმენით ცარიელი ლისტი, რომელსაც შეავსებთ შემთხვევითი რიცხვებით, 
# დაბეჭდეთ ელემენტებიდან მინიმალური და მაქსიმალური მნიშვნელობები

x = list()

#Enter -1 to stop the programme
a = -1

b = int(input("Enter your number:"))

while b != a:
    x.insert(len(x), b)
    b = int(input("Enter your number:"))

print("max: ", max(x))
print("min: ", min(x))
