# დაწერეთ პითონის პროგრამა, რომელიც შექმნის ლისტს my_llist = [43, '22', 12, 66, 210, ["hi"], და შეასრულებს

# შემდეგ ნაბიჯებს:

# a. დაბეჭდავს 210-ის ინდექს, თუ მერამდენე ინდექსზეა

# b. დაამატებს ბოლო ელემენტში ტექსტს "hello"

# c. წაშლის მეორე ინდექსზე მდგომ ელემენტს და დაბეჭდავს ლისტს

# d. შექმენით ახალი ლისტი my_llist_2 , რომელსაც ექნება my_llist მნიშვნელობა, გაასუფთავეთ my_llist_2

# მნიშნველობა და დაბეჭდეთ my_llist და my_llist_2 ლისტები

my_llist = [43, '22', 12, 66, 210, ["hi"]]

#a
print("a: ", my_llist.index(210))

#b
my_llist.insert(len(my_llist), "hello")
print("b: ", my_llist)

#c
my_llist.remove(my_llist[2])
print("c: ", my_llist)

#d
my_llist_2 = my_llist
my_llist_2.clear()

print("d: ", my_llist, ", ", my_llist_2)
