
# დაწერეთ ფუნქცია, რომელიც დააგენერირებს 100 შემთხვევითობის პრინციპით დაგენერირებული ელემენტისგან შემდგარ ლისტს, გამოიყენეთ ორი სორტირების ალგორითმი(არ აქვს არსებითი მნიშვნელობა, რომელი ალგორითმები იქნება), ერთი ალგორითმით დაასორტირეთ ზრდადობით, მეორე ალგორითმით დაასორტირეთ კლებადობით, ორივე შედეგი დაპრინტეთ ტერმინალში.


import random


def randlist():
    n = 100

    lst = [0]*n

    for i in range(n):
        a = int(random.random()*n)
        lst[i] = a

    return lst

# selection sort > desc

lst = randlist()
#tst
print(f"input: {lst}")

def selectionSort(lst):
    for i in range(len(lst)):
        maxindex=i
        for j in range(i+1, len(lst)): 
            if(lst[i]<lst[j] and lst[maxindex]<lst[j]):
                    maxindex=j   
        lst[i], lst[maxindex] = lst[maxindex], lst[i]
    return lst

print(selectionSort(lst))

# quick sort > asc

def quickSort(lst):
     
    length = len(lst)

    if length <= 1:
         return lst
    else:   
        pivot = lst.pop()

    gn = []
    ln = []

    for n in lst:
         if n < pivot:
              ln.append(n)
         else:
              gn.append(n)

    return quickSort(ln) + [pivot] + quickSort(gn)

print(quickSort(lst))

