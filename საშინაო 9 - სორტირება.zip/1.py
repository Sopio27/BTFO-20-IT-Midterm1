
# დაწერეთ ფუნქცია, რომელიც დააგენერირებს 100 შემთხვევითობის პრინციპით დაგენერირებული ელემენტისგან შემდგარ ლისტს, გამოიყენეთ sort() მეთოდი და sorted() ფუნქცია, დააბრუნეთ დასორტირებული ლისტი ჯერ ზრდადობით და შემდეგ კლებადობით

import random


def randlist():
    n = 100

    lst = [0]*n

    for i in range(n):
        a = int(random.random()*n)
        lst[i] = a

    return lst


lst = randlist()

#SORT()
lst.sort()
print(lst)
lst.sort(reverse=True)
print(lst)

#Sorted()
listAsc = sorted(lst)
listDesc = sorted(lst, reverse=1)

print(listAsc)
print(listDesc)

