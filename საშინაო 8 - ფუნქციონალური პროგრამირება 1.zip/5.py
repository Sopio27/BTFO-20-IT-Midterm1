import functools

try:
    numsx = input("Pass a list of numbers:")
    numslist = numsx.split(",")
    listInt = map(int, numslist)

    factorial = functools.reduce(lambda a, b: a*b, listInt)

    print(factorial)
except:
    print("Invalid Data Type")
