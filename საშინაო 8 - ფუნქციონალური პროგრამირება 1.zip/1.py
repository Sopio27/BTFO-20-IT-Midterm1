
# დაწერეთ პითნის ფუნქცია, რომელიც იღებს პარამეტრად ერთი და იგივე ზომის სიას(list) და zip ფუნქციის გამოყენებით დააჯგუფეთ სიების ელემენტები ერთმანეთთან.

# params: [1, 2, 3], ['a', 'b', 'c']

# outputs: ["(1, 'a')", "(2, 'b')", "(3, 'c')"]

import functools

# nums = [1,2,3]
# chars = ['a','b','c']

print("input an equal number of parameters into both lists")


numsx = input("Pass a list of numbers:")
charsx = input("Pass a list of characters:")

numslist = numsx.split(",")
charslist = charsx.split(",")


while(len(numslist) != len(charslist)): 
    print("Please, input an equal number of parameters into both lists")
        
    numsx = input("Pass a list of numbers:")
    charsx = input("Pass a list of characters:")

    numslist = numsx.split(",")
    charslist = charsx.split(",")

innerjoin = list(zip(numslist, charslist))

print(innerjoin)