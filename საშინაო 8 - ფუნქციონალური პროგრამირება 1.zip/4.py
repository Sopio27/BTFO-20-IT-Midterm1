import functools

stringx = input("Pass a list of strings:")
stringList = stringx.split(",")

def reverse(a):
    b=''
    for i in range(len(a) - 1, -1,-1):
        b = b + a[i]
    return b

palindromeList = list(filter(lambda a: a == reverse(a), stringList))

print(palindromeList)