import functools

numsx = input("Pass a list of numbers:")
numslist = numsx.split(",")
listInt = map(int, numslist)

oddValues = list(filter(lambda a: a%2 == 1, listInt))

print(oddValues)