import functools
import string

try:
    stringx = input("Pass a list of strings:")
    stringList = stringx.split(",")

    suffix = input("pass ending:")

    ending = list(filter(lambda x: x.endswith(suffix), stringList))

    print(ending)
except  Exception as e:
    print(f"Error {e}")
