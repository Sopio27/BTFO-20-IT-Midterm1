import functools

numsx = input("Pass a list of numbers:")
numslist = numsx.split(",")
listInt = map(int, numslist)

positiveNumbers = list(filter(lambda a: a > 0, listInt))

print(positiveNumbers)