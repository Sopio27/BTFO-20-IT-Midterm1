# დავალება 1.

# დაწერეთ პითონის ფუნქცია რომელიც დააგენერირებს 100 შემთხვევითობის პრინციპით არჩეული რიცხვებით შევსებულ ლისტს.
# დაწერეთ ფუნქცია, რომელიც ხაზობრივი ძიების გამოყენებით მოიძიებს მოცემულ ლისტში რომელიმე ელემენტს.
# გამოიყენეთ ერთ-ერთი სორტირების ალგორითმი და დასორტირებულ სიაში ელემენტის ძიებისთვის დაწერეთ ბინარული ძიება.

import random

#num of elements
n = 100

#100 rand nums
def randlist():
    global n

    listX = [0]*n

    for i in range(n):
        a = int(random.random()*n)
        listX[i] = a

    return listX

#rand list
listX = randlist()
listXMaxIndex = len(listX) - 1
# listX.sort()

#rand num from the list
x = listX[random.randint(0,n-1)]

#1 linear search (rec)
def linearSearchRecursive(listX, charIndex, x):

    if charIndex == len(listX):
        return -1
    
    if listX[charIndex] == x:
        return charIndex
    else:
       return linearSearchRecursive(listX, charIndex + 1, x)
    
positionOfX = linearSearchRecursive(listX, 0, x)

print(f"List: {listX}")
print(f"Index of number {x} in the list using recursive linear search: {positionOfX}")

#2
#2.1 sort using an algorithm
#selection sort
def selectionSort(lst):
    for i in range(len(lst)):
        minIndex=i
        for j in range(i+1, len(lst)): 
            if(lst[i]>lst[j] and lst[minIndex]>lst[j]):
                    minIndex=j   
        lst[i], lst[minIndex] = lst[minIndex], lst[i]
    return lst

listXSorted = selectionSort(listX)

#2.2 search in the sorted list
#binary search(rec)

def binarySearchRecursive(listSorted, min, max, x):

   if max == -1 or min == len(listSorted):
    return -1
   
   mid =  (min + max) // 2

   if listSorted[mid] == x:
       return mid
   if listSorted[mid] < x:
       return binarySearchRecursive(listSorted, mid+1, max, x)
   if listSorted[mid] > x:
       return binarySearchRecursive(listSorted, min, mid-1, x)
   

positionOfXBinary = binarySearchRecursive(listXSorted, 0,listXMaxIndex, x)
print(f"List: {listXSorted}")
print(f"Index of number {x} in the list using recursive binary search: {positionOfXBinary}")

