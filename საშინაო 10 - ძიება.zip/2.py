# დაწერეთ ლამბდა ფუნქცია, რომელიც დააბრუნებს სამის ჯერად რიცხვებს,
# ამის შემდეგ დაწერეთ ფუნქცია, რომელსაც ატრიბუტებად გადაეწოდება ლისტი და ლამბდა ფუნქცია, ხაზობრივი ძიების და ლამბდა ფუნქციის დახმარებით შეავსეთ ახალი ლისტი(ინდექსებით) და დააბრუნეთ მოცემული ლისტი.(ფუნქციამ უნდა დააბრუნოს ლისტი, რომელშიც შენახული იქნება სამის ჯერადი რიცხვების ინდექსები)

#ლამბდა ფუნქცია აბრუნებს 3-ის ჯერადებს ლისტში

#ჯერადი
m = 3
#ჯერადების რაოდენობა
n = 6


lst=[]

listX =  [lambda x = i: x * m for i in range(1,n+1)]

for i in listX:
    lst.append(i())
    
print(lst)


# ფუნქციას მიეცემა ლისტი და უნდა ნახოს ამ ლისტში 3-ის ჯერადი რიცხვი რომელ პოზიციებზეა და ამ პოზიციების ლისტი დააგენერიროს

listForFunction = [1,2,3,4,5,6]

def linearSearchRecursive(listX, charIndex, x):

    if charIndex == len(listX):
        return -1
    if listX[charIndex] == x:
        return charIndex
    else:
       return linearSearchRecursive(listX, charIndex + 1, x)
    

def indexOfMulitples(listX, LambdaFunction):
 
    lst=[]
    for i in LambdaFunction:
        lst.append(i())

    res = []
    for i in range(len(lst)):
        k = linearSearchRecursive(listX, 0,lst[i])
        
        if k != -1: res.append(k)

    return res

indexed = indexOfMulitples(listForFunction, listX)
print(f"List of indexes: {indexed}")
