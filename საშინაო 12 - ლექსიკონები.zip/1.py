# დაწერეთ პითონის პროგრამა, რომელიც მომხმარებელს სთხოვს შეიყვანოს წინადადება, პროგრამას დააბეჭდინეთ დიქტის სახით რამდენჯერ არის თითოეული სიტყვა გამოყენებული წინადადებაში

# input: The wind howled and howled all night long

# output: {“the”: 1, “wind”:1, “howled”:2, “and”:1, “all”:1, ”night”:1, “long”:1}

userInput = input("Please, enter your sentence: ")

dictUserInput = {}

counter = 0

lstOfWords  = userInput.split(" ")

for i in range(len(lstOfWords)):
    if(dictUserInput.get(lstOfWords[i]) == None):
        dictUserInput[lstOfWords[i]] = 1

    else:
        dictUserInput[lstOfWords[i]] += 1

print(dictUserInput)