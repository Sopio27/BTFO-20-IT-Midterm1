# დაწერეთ პითონის პროგრამა, რომელიც მომხმარებელს სთხოვს შეიყვანოს ორი რიცხვი და ერთი მათემატიკური ოპერატორი, ააწყვეთ კალკულატორი, რომელიც გამოთვლის შესაბამის მოქმედებას, გამოიყენეთ დიქტები, სადაც key მნიშვნელობებად იქნება მათემატიკური ოპერატორები

a = int(input("a: "))
b = int(input("b: "))
o = input("operator: ")

def addition(a,b):
    return a+b

def subtraction(a,b):
    return a-b

def multiplication(a,b):
    return a*b

def division(a,b):
    return a/b

dictCalc = {
    "+": addition
    , "-": subtraction
    , "*": multiplication
    , "/": division
    }

print(dictCalc[o](a,b))