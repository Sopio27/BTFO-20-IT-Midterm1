lst = [1,2,3,3,5]

c = 0

def IsMonotonous(a):
    for i in  range(1,len(lst)):
        if lst[i-1] < lst[i]:
            c = 1
        else:
            c=0 
            break
    if(c==1): return "Monotonous, ascending"
    else:
        for i in range(1,len(lst)):
            if lst[i-1] > lst[i]:
                c = 1
            else:
                c=0 
                break
    if(c==1): return "Monotonous, descending"
    else: return "Not monotonous"

print(IsMonotonous(lst))
    