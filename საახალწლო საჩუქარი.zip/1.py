# დაწერეთ პითონის პროგრამა, რომელიც მომხმარებელს შეაყვანინებს რიცხვს და დაგვიბეჭდავს ამ 
# რიცხვის ყველაზე დიდ გამყოფს, რომელიც თავად ამ რიცხვზე ნაკლებია.


a = int(input("Enter a positive number:"))
k=0


while a<0:
 a = int(input("Please, enter a positive number:"))

for i in range(1, a-1):
 if(a%i == 0 and i>k):
  k=i

if(a==1): print(1)
else: print(k)