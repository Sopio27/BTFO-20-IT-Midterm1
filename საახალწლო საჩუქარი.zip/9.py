# დაწერეთ თამაში ჯეირანი

import random
import string
import time

valuesforuser = ["Rock", "Paper", "Scissors", "1", "2", "3"]

dictuser = {
    1:valuesforuser[0],
    2:valuesforuser[1],
    3:valuesforuser[2]
}

Winner = 3
CounterUser = 0
CounterComp = 0

#move, move, winnermove
moves = [[1,2,2],[1,3,1],[2,3,3]]


txt1=f"\nWelcome to game Rock-Paper-Scissors!\n\nPlease, enter the number or the name of the move on your turn.\n\nUse the following mapping:\n{dictuser}\n\nWhoever reaches score {Winner} first, gets the trophy!\n\nBest of luck!"

def printtext(txt):
    for i in range(len(txt)+2):
       a="\n\n"+txt        
       print(a[i], end='')
       time.sleep(0.06)

printtext(txt1)

def checkvaluesfunc(a):
    for i in valuesforuser:
        if valuesforuser.__contains__(a):
            return True
    return False
            
def winnermove(x, y):
    for i in range(0,len(moves)):
        if(moves[i][0]==x and moves[i][1]==y):
            return(moves[i][2])
        if(moves[i][0]==y and moves[i][1]==x):
            return(moves[i][2])
           
while(True):
    a = input("\n\nYour move: ").capitalize()
    valueUser = 0

    while(not(checkvaluesfunc(a))):
        a = input("\nPlease, enter a valid move number or name: ").capitalize()

    if(len(a)!=1):
        keys = [k for k, v in dictuser.items() if v == a]
        valueUser=keys[0]
    else: valueUser=int(a)
    
    valueComp = random.randint(1,3)

    time.sleep(1)
    print("\nRock...")
    time.sleep(1)
    print("Paper...")
    time.sleep(1)
    print("Scissors!")
    time.sleep(1)

    print(f"\nComputer: {dictuser.get(valueComp)}")

    if(valueComp==valueUser):
        print("\nIt's a tie")
        print(f"\nScoreboard\nUser: {CounterUser}\nComputer: {CounterComp}")
        continue

    w = winnermove(valueUser, valueComp)

    if(valueComp==w):
        CounterComp+=1
        print("\nComputer earns a single point.")
    elif(valueUser==w):
        CounterUser+=1
        print("\nYou earn a single point!")
    else:"Error"

    print(f"\nScoreboard\nUser: {CounterUser}\nComputer: {CounterComp}")

    if(CounterUser==Winner):
        print("\nYou won! Good job!")
        break

    if(CounterComp==Winner):
        print("\nYou lost! Try Again?")
        break
    

    
