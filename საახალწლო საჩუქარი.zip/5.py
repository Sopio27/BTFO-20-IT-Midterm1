# დაწერეთ პროგრამა რომელიც მომხმარებელს შეაყვანინებს რიცხვს და დაგვიბეჭდავს ეს რიცხვი არის თუ არა მარტივი, თუ არ არის დაგვიბეჭდავს ეს არის რთული რიცხვი და დაბეჭდავს ასევე მის გამყოფებს

a = int(input("Please, enter a positive number:"))

while a<0:
 a = int(input("Please, enter a positive number:"))

def gcd2(a):
    k = 0
    for i in range(1, a-1):
     if(a%i == 0 and i>k):
         k=i
    return k

if a ==1:
   print ("1 neither prime nor composite")
elif gcd2(a) == 1:
   print(f"{a} is a prime number")
else:
    lst=[]

    for i in range(1, a+1):
       if a%i == 0:
          lst.insert(len(lst) ,i)
    
    print(f"{a} is not a prime number: {lst}")
