
# დაწერეთ პითონის ფუნქცია რომელიც ატრიბუტად მიიღებს ინტეჯერებისგან შემდგარ ლისტს, ლისტში შესაძლოა იყოს დუბლიკატები, ფუნქციამ უნდა დააბრუნოს ლისტი დუბლიკატების გარეშე

lst = [1,2,3,3,4,4,5,5,5,6]
distlst = []

def dist(a):
    for i in range(len(lst)):
        if distlst.__contains__(lst[i]):
            continue
        else:
            distlst.insert(len(distlst), lst[i])
    return distlst

print(dist(lst))