lst = ["Green", "Blue", "rED"]
rangex = 32
output = []


for i in range(0,len(lst)):
    res=''
    for j in range(len(lst[i])):  
        a = lst[i]
        if(ord(a[j])>96 and ord(a[j])<123):
            res+=chr(ord(a[j])- rangex)
        else:
            res+=chr(ord(a[j])+rangex)
    output.insert(i, res)

print(output)

       
