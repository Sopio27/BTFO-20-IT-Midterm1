# დაწერეთ პითონის პროგრამა რომელიც ატრიბუტად მიიღებს ერთ რიცხვს და დაბეჭდავს 1-დან ამ რიცხვის ჩათვლით მოქმედებებს: x**2, x**10, x**x შემდეგი სახით

import math

a = 15
tmplist = []
powlist = [2,10]

for i in range(a):
    tmplist.insert(i,i+1)

for i in range(3): #0 1 2
   for j in tmplist: #j==გადაცემული რიცხვები
       a=tmplist[j-1]
       if(i<2):
        b=powlist[i]
        y = int(math.pow(a,b))
        if b == 2:
            print(f"{a}*{a} {y}")
        elif b == 10:
           print(f"{a}^{b} {y}")
       else:
        y= int(math.pow(a,a))
        print(f"{a}^{a} {y}")