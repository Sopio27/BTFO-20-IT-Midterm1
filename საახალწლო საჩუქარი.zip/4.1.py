a = input("Enter a word containing latin characters:")
indent = int(input("Enter any positive number: "))

max = 26
l=indent%max

res=''

for i in range(1,len(a)+1):

    if ord(a[i-1]) <= 90: min = 64
    else: min=96

    if ord(a[i-1]) - l > min:
        res+=chr(ord(a[i-1])-l)
    else:
        res+=(chr(abs(l-max)+ord(a[i-1])))

print(res)