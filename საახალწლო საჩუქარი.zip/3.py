# დაწერეთ პითონის პროგრამა რომელიც ტერმინალში გვიჩვენებს მიმდინარე 
# დროს ერთ ხაზზე სანამ ჩვენ არ გავაჩერებთ (Ctrl+c).
# მიმდინარე დროის საპოვნელად გამოიყენეთ პითონის მოდული datetime
# from datetime import datetime
# time_now = datetime.now()

from datetime import datetime

import os

while (True):
 print(datetime.now())
 os.system('cls')