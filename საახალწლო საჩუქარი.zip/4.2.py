import datetime

a = int(input("Enter a year:"))

b = datetime.date(a,3,1)
b = b + datetime.timedelta(days=-1)

if b.day == 29: print('ნაკიანი')
else: print('არაა ნაკიანი')

