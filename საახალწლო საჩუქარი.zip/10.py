import random
import time
import copy

#declare values

#gaming board for calculation
boardTempalte = [[None, None, None],[None,None,None],[None,None,None]]
board = copy.deepcopy(boardTempalte)

#gaming board displayed to user
userBoardTemplate = [[1, 2, 3],[4,5,6],[7,8,9]]
userBoard = copy.deepcopy(userBoardTemplate)

#numberpad
userValues = [1,2,3,4,5,6,7,8,9]
availableValues = copy.deepcopy(userValues)

#player
userToBoardMap = {}
userKeys = {
    "Player1": 1,
    "Player2": 0,
    "1": 1,
    "2": 0
}
playerkey=0

#turn
turn = 1

#intro
#skip intro
skipintrobool="No"

#start intro
isintrotime = True

#user input to player key map
counter = 0

for i in range(0,3):
    for j in range(0,3):
        lst = []
        userToBoardMap[userValues[counter]] = [i,j]
        counter+=1

#check available values
def checkvaluesfunc(a):
    for i in availableValues:
        if availableValues.__contains__(a):
            return True
    return False

#assign value to the board
def assignValue(a, b, turn):
    coordinates = userToBoardMap.get(a)
    x=coordinates[0]
    y=coordinates[1]
    board[x][y] = b
    availableValues.remove(a)
    if(turn):
        userBoard[x][y]="O"
    else:
        userBoard[x][y]="X"

    
#Check for win
def iterateOverBoard(x,y, usersymbol):
    #iterate rows
    countRows=0
    for i in range(0,3):
        if(board[x][i]==usersymbol):
            countRows+=1

    if countRows == 3: return 1

    #iterate columns
    countColumns =0
    for i in range(0,3):
        if(board[i][y]==usersymbol):
            countColumns+=1

    if countColumns == 3: return 1

    #iterate diagonals
    SouthEastDiagonal = 0
    SouthWestDiagonal = 0

    for i in range(0,3):
        if(board[i][i]==usersymbol):
            SouthEastDiagonal+=1

    if SouthEastDiagonal == 3: return 1

    for i in range(2,-1,-1):
        if(board[i][abs(i-2)]==usersymbol):
            SouthWestDiagonal+=1

    if SouthWestDiagonal == 3: return 1

    return 0

#players move
def check(b, playerkey):
    coordinates = userToBoardMap.get(b)
    x=coordinates[0]
    y=coordinates[1]
    userSymbol = playerkey
    res = iterateOverBoard(x,y,userSymbol)
    return res

#restart global values if rematch is called
def rematch():
    global board
    global userBoard
    global turn
    global isintrotime
    global boardTempalte
    global userBoardTemplate
    global availableValues

    board.clear()
    userBoard.clear()

    board = copy.deepcopy(boardTempalte)
    userBoard = copy.deepcopy(userBoardTemplate)
    availableValues= copy.deepcopy(userValues)

    turn=1
    isintrotime=True


#print delayed text
def printtext(txt):
    for i in range(len(txt)+2):
       a="\n\n"+txt        
       print(a[i], end='')
       time.sleep(0.06)

#game introduction
def intro():

    if(skipintrobool=="No"):
        text1 = "Welcome to Tic-Tac-Toe!\n\nInstructions are simple! Enter a number to mark your position on the board."
        printtext(text1)

    text2_1 = "You will be assigned to 'X'. Good luck!"
    text2_2 = "You will be assigned to 'O'. Good luck!"
    playertext="Do you wish to be player1 or player2?"
    printtext(playertext)

    answer = input("\n\nAnswer: ").capitalize()
    answerlist ={"Player1", "Player2","1","2"}

    while answer.capitalize() not in answerlist:
        answer = input("\n\nSorry, such player couldn't be found. Please, re-enter your choice: ").capitalize()

    playerkey = userKeys.get(answer)

    if(playerkey==1): printtext(text2_1)
    else: print(text2_2)

    time.sleep(0.8)

    return playerkey

#main
while(True):

    #call introduction
    if(isintrotime):
        playerkey = intro()
        isintrotime=False

    #board border
    print("\n")
    print("-"*65)

    #current state of the board
    for i in range(0,3):
            print(f"\n{userBoard[i]}")
    #baord border
    print("\n")
    print("-"*65)


    time.sleep(0.8)

    a=0

    #user
    if(playerkey==1):
        print(f"\nList of available positions:{availableValues} ")
        a = int(input("\nEnter your position: "))

        if(not(checkvaluesfunc(a))):
            a = int(input("\nPlease, enter a position from the list of available values: "))
    #computer
    else:  
        a = random.choice(availableValues)
        prnttxt =f"\nComputer chose position {a}."
        printtext(prnttxt)
        time.sleep(0.8)

    #write value in the board
    assignValue(a, playerkey, turn%2==0)
    #check for win
    res = check(a,playerkey)

    #win
    if (res==1):
        #user win
        if(playerkey==1):
            print("\n\nCongrats! You won!")
        #computer win
        else:
            print("\n\nYou lost! Try again?")

        #ask for a rematch
        b = int(input("\n\nEnter 1 to play again or any other number to end the game:"))
        if b==1: 
            skipintrobool = input("\n\nSkip intro? Enter Yes/No: ").capitalize()
            rematch()
        else:
            print("\nBye!")
            break
    #tie
    elif not availableValues:
        print("\n\nNo winner. Play again?")
        
        b = int(input("\n\nEnter 1 to play again or any other number to end the game: "))
        
        if b==1: 
            skipintrobool = input("\n\nSkip intro? Enter Yes/No: ").capitalize()
            rematch()
        else:
            print("\nBye!")
            break
    #next move
    else:
        if playerkey==1: playerkey-=1
        else: playerkey+=1
        turn+=1
        