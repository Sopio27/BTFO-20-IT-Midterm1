total_sum = float(0)

breaker = "sum"

a = input("Enter a positive number:")

while a != breaker:
    if float(a) > 0:
        total_sum+=float(a)
    else:
        print("Please, Enter a positive numebr:")   
    a = input("Enter a positive number:")
    
print(total_sum)