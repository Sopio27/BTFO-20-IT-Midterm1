#V1 - პირველ ვერსიაში გათვალისწინებულია ფორმატინგი. V2 ჩვეულებრივად ბეჭდავს.
a = int(input("Enter your number:"))

while a > 0:
    if(a == 1):
        print(a)
    else:
        print(f'{a}, ', end='')
    a-=1

#V2

# a = int(input("Enter your number:"))

# while a > 0:
#     print(a)
#     a-=1