import string

x = input("Enter a sentence:")
y = input("Enter a single character: ")

a = len(y)

while(a!=1):
    y = input("Please, Enter a single character:")
    a = len(y)

def counter(sentence, character):
    s = sentence
    c = character

    counter = 0

    for i in (range(len(s))):
        if(s[i]==c):
            counter+=1

    return counter

print(counter(sentence=x, character=y))