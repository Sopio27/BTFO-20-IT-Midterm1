#case-sensitive
import string

s = input("შეიყვანეთ სიტყვები სასურველ ენაზე: ")

def IsAnagram(z):

    z = z.replace("  ", " ")
    z = z.strip()

    r = z.split(" ")

    for i in (range(len(r)-1)):
        if len(r[i]) != len(r[i+1]):
            return "Not an anagram"
        else:
            k = 0

            for i in (range(len(z))):
                    l = ord(z[i])
                    if l>=k:
                        k = l

            for i in range(len(r)-1):

                a = [0]*(k+1)
                b = [0]*(k+1)
                
                x = r[i]

                for j in range(len(r[i])):
                    a[ord(x[j])] += 1

                y = r[i+1]
                for d in range(len(r[i+1])):
                    b[ord(y[d])] += 1

                if a == b:
                    continue
                else:
                    return "Not an anagram"
                    break
    return "Anagram"

a = IsAnagram(s)

print(a)