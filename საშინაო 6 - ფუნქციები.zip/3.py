import string

a = int(input("Enter a desired number: "))

def fibonacci(a):

    x1 = [0,1]
    x2 = [0]*(a-2)

    if a < 3:
        return(x1[0:a])

    fibonacci = x1+x2

    for i in range(2, len(fibonacci)):
        fn = fibonacci[i-1]+fibonacci[i-2]
        fibonacci[i]= fn
        
    return(fibonacci)

print(fibonacci(a))


