# დავალება 2.

# გამოიყენეთ organizations-100.csv

# წაიკითხეთ მოცემული csv ფაილი, შექმენით ახალი csv ფაილი “ssl_companies.csv” და ჩაწერეთ მხოლოდ აიდი, კომპანიის სახელი, ვებ საიტი, ინდუსტრია და დასაქმებულების რაოდენობა ისეთი კომპანიების რომელთაც აქვთ ssl-ით დაცული ვებსაიტი(HTTPS)

import csv

with open("organizations-100.csv", "r") as orgRawData:

    reader_csv = csv.DictReader(orgRawData)

    orgSSL = [row for row in reader_csv if row["Website"].__contains__("https")]

    with open("ssl_companies.csv", "w") as orgSSLData:
        headers = ['Organization Id','Name','Website','Industry','Number of employees']

        writer_csv = csv.DictWriter(orgSSLData, fieldnames=headers)
        writer_csv.writeheader()
        for rowdict in orgSSL:
         writer_csv.writerow({'Organization Id': rowdict['Organization Id'], 
                              'Name': rowdict['Name'],
                              'Website': rowdict['Website'],
                              'Industry': rowdict['Industry'],
                              'Number of employees': rowdict['Number of employees']})