
# გამოიყენეთ titanic.csv
# წაიკითხეთ მოცემული csv ფაილი, შექმენით ახალი csv ფაილი “survived.csv” და ჩაწერეთ მხოლოდ გადარჩენილების ინფორმაცია.

import csv

#survived = 1

with open("titanic.csv", "r") as fileStart:
    
    readFile = csv.DictReader(fileStart)

    survivorsFile = [row for row in readFile if row["Survived"] == "1"]


    with open("survived.csv", "w") as fileDest:
        
        headers = ['PassengerId','Survived','Pclass','Name','Sex','Age','SibSp','Parch','Ticket','Fare','Cabin','Embarked']

        fileDest = csv.DictWriter(fileDest, fieldnames=headers)
        fileDest.writeheader()
        fileDest.writerows(survivorsFile)
         
            