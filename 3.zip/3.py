
# დავალება 3.

# გამოიყენეთ organizations-100.csv

# წაიკითხეთ მოცემული csv ფაილი, შექმენით ახალი csv ფაილი “sorted_csv.csv” და ჩაწერეთ დასორტირებული ინფორმაცია, დაასორტირეთ თანამშრომელთა რაოდენობის მიხედვით

import csv

with open ("organizations-100.csv", "r") as fileReader:

    readercsv = csv.DictReader(fileReader)
    sortedReader = sorted(readercsv, key = lambda row: row['Number of employees'] )

    with open("sorted_csv.csv", "w") as fileWriter:

        headers = [
            'Index','Organization Id','Name','Website','Country','Description','Founded','Industry','Number of employees'
        ]

        writercsv= csv.DictWriter(fileWriter, fieldnames=headers)
        writercsv.writeheader()

        writercsv.writerows(sortedReader)

        